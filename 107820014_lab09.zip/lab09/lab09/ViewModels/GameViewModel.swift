//
//  GameViewModels.swift
//  lab09
//
//  Created by 謝昀羲 on 2021/5/26.
//

import Foundation

class GameViewModel: ObservableObject{
    @Published var playerFinger: String?
    @Published var computerFinger: String?
    @Published var result: GameResult?
    
    var fingers = Finger()
    
    func play(){
        playerFinger = fingers.randomFinger()
        computerFinger = fingers.randomFinger()
        result = checkResult()
    }
    
    func checkResult() -> GameResult{
        if playerFinger == computerFinger {
            return .tie
        }else if playerFinger == "paper" && computerFinger == "stone" {
            return .win
        }else if playerFinger == "scissor" && computerFinger == "paper" {
            return .win
        }else if playerFinger == "stone" && computerFinger == "scissor" {
            return .win
        }else{
            return .lose
        }
    }
}
