//
//  GameView.swift
//  lab09
//
//  Created by 謝昀羲 on 2021/5/26.
//

import SwiftUI

struct GameView: View {
    @StateObject var gameViewModel = GameViewModel()
    var body: some View {
        VStack{
            Text("猜拳遊戲")
                .font(.title)
                .padding()
            HStack{
                Text("玩家：")
                    .padding()
                Image("\(gameViewModel.playerFinger ?? "stone")")
                    .resizable()
                    .frame(width: 100, height: 100, alignment: .center)
                    .scaledToFit()
                Text(gameViewModel.playerFinger ?? "?")
                    .padding()
            }
            HStack{
                Text("電腦：")
                    .padding()
                Image("\(gameViewModel.computerFinger ?? "stone")")
                    .resizable()
                    .frame(width: 100, height: 100, alignment: .center)
                    .scaledToFit()
                Text(gameViewModel.computerFinger ?? "?")
                    .padding()
            }
            ZStack{
                Image("paperscissorstone")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300, alignment: .center)
                    .padding()
                Button(action: {
                    gameViewModel.play()
                }, label: {
                    Text("出拳！")
                        .padding()
                })
            }
            HStack{
                Text("結果：")
                Text(gameViewModel.result?.rawValue ?? "請按\"出拳\"開始猜拳")
            }
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
