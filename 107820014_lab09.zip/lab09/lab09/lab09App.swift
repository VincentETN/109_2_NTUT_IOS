//
//  lab09App.swift
//  lab09
//
//  Created by 謝昀羲 on 2021/5/24.
//

import SwiftUI

@main
struct lab09App: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
