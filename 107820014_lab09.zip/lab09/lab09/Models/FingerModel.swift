//
//  FingerModel.swift
//  lab09
//
//  Created by 謝昀羲 on 2021/5/26.
//

import Foundation

class Finger{
    private var fingers: [String] = ["paper", "scissor", "stone"]
    
    func randomFinger() -> String{
        return fingers.randomElement() ?? "?"
    }
}
