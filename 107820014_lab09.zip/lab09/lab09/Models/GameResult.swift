//
//  GameResult.swift
//  lab09
//
//  Created by 謝昀羲 on 2021/5/26.
//

import Foundation

enum GameResult: String{
    case win = "玩家獲勝！"
    case lose = "電腦獲勝！"
    case tie = "平手！"
}
