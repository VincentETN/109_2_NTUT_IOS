//
//  IntroductionView.swift
//  spclass2
//
//  Created by 謝昀羲 on 2021/5/5.
//

import SwiftUI

struct IntroductionView: View {
    let character = ["笹川了平", "獄寺準人", "澤田綱吉", "三本武", "藍波"]
    var body: some View {
        VStack{
            Image("character")
                .resizable()
                .scaledToFit()
            HStack{
                ForEach(character.indices){ index in
                    Text(character[index])
                        .padding()
                }
            }
        }
        .navigationTitle("Introduction")
        
    }
}

struct IntroductionView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            IntroductionView()
        }
    }
}
