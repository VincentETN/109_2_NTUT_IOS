//
//  ContentView.swift
//  spclass2
//
//  Created by 謝昀羲 on 2021/5/3.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            VStack{
                Image("Reborn")
                    .resizable()
                    .scaledToFit()
                NavigationLink(
                    destination: IntroductionView(),
                    label: {
                        Text("Introduction")
                    })
            }
            .navigationTitle("家庭教師Reborn!")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
