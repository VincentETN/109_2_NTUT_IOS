//
//  spclass2App.swift
//  spclass2
//
//  Created by 謝昀羲 on 2021/5/3.
//

import SwiftUI

@main
struct spclass2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
