//
//  Calculator.swift
//  calculator
//
//  Created by 謝昀羲 on 2021/5/1.
//

import Foundation

class Calculator{
    private var numbers = [Float]()
    private var operators = [String]()
    
    func allClean(){
        numbers.removeAll()
        operators.removeAll()
    }
    
    func appendNumber(number: Float){
        numbers.append(number)
    }
    
    func appendOperator(op: String){
        operators.append(op)
    }
    
    func calculate() -> Float{
        while numbers.count > 1 {
            if let opIndex = operators.firstIndex(of: "÷"){
                if numbers[opIndex+1] == 0 {
                    return 0
                }else{
                    numbers[opIndex] /= numbers[opIndex+1]
                    numbers.remove(at: opIndex+1)
                    operators.remove(at: opIndex)
                }
            }else if let opIndex = operators.firstIndex(of: "×"){
                numbers[opIndex] *= numbers[opIndex+1]
                numbers.remove(at: opIndex+1)
                operators.remove(at: opIndex)
            }else if let opIndex = operators.firstIndex(of: "-"){
                numbers[opIndex] -= numbers[opIndex+1]
                numbers.remove(at: opIndex+1)
                operators.remove(at: opIndex)
            }else if let opIndex = operators.firstIndex(of: "+"){
                numbers[opIndex] += numbers[opIndex+1]
                numbers.remove(at: opIndex+1)
                operators.remove(at: opIndex)
            }
        }
        return numbers[0]
    }
}
