//
//  ViewController.swift
//  calculator
//
//  Created by 謝昀羲 on 2021/3/8.
//

import UIKit

class ViewController: UIViewController {
    
    var calculator:Calculator = Calculator()
    
    var tempOP:String?
    var choosingOP:Bool = false
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var processLabel: UILabel!
    
    @IBAction func numButton(_ sender: UIButton) {
        if tempOP != "=" {      // 等於後不動作
            if resultLabel.text == "0" {
                resultLabel.text = ""
            }
            if choosingOP {
                choosingOP = false
                resultLabel.text = ""
                calculator.appendOperator(op: tempOP!)
            }
            resultLabel.text!.append(sender.currentTitle!)
        }
    }
    
    @IBAction func buttonPoint(_ sender: Any) {
        if !resultLabel.text!.contains("."){
            resultLabel.text!.append(".")
        }
    }
    
    @IBAction func sign(_ sender: Any) {
        if resultLabel.text != "0" {
            if resultLabel.text!.hasPrefix("-") {
                resultLabel.text!.removeFirst()
            }else{
                resultLabel.text!.insert("-", at: resultLabel.text!.startIndex)
            }
        }
    }
    
    @IBAction func percent(_ sender: Any) {
        if resultLabel.text!.last != "%" {
            resultLabel.text!.append("%")
        }
    }
    
    @IBAction func opButton(_ sender: UIButton) {
        if tempOP != "=" {
            tempOP = sender.currentTitle
            if !choosingOP {
                var floatNum:Float?
                if resultLabel.text!.last == "%" {
                    floatNum = Float(resultLabel.text!.dropLast())! / 100
                }else{
                    floatNum = Float(resultLabel.text!)
                }
                let intNum = Int(floatNum!)
                calculator.appendNumber(number: floatNum!)
                // 處理多餘的０
                if Float(intNum) != floatNum {
                    processLabel.text!.append(String(floatNum!))
                }else{
                    processLabel.text!.append(String(intNum))
                }
                processLabel.text!.append(tempOP!)
                choosingOP = true
            }else{
                processLabel.text!.removeLast()
                processLabel.text!.append(tempOP!)
            }
            if sender.tag == 0 {
                let floatAns = calculator.calculate()
                let intAns = Int(floatAns)
                if Float(intAns) != floatAns {
                    resultLabel.text = String(floatAns)
                }else{
                    resultLabel.text = String(intAns)
                }
            }
        }
    }
    
    @IBAction func allClear(_ sender: Any) {
        resultLabel.text = "0"
        processLabel.text = ""
        choosingOP = false
        tempOP = nil
        calculator.allClean()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

